# Pandora Moments – 970×250 media-first rich media masthead

[Pandora2027.html](release/Pandora2027.html) referans çalışmasının yeniden tasarımı: tr.pandora.net’teki gerçek ürünler, güncel TL fiyatları, kampanya ve marka kimliğiyle; fotoğraf önde (media-first), bileklik tasarlayıcı elinin altında.

| Dosya | Açıklama |
|---|---|
| `release/Pandora2027.html` | Teslim: tek dosyalık 970×250 masthead (görseller, logo ve font gömülü) |
| `dist/970x250/index.html` + `dist/zip/pandora-moments-970x250.zip` | Reklam ağına yüklenecek aynı dosya / zip |
| `release/sunum.html` | Tek dosyalık sunum: masthead gömülü, yayın simülasyonu, ekran görüntüleri |
| `preview/index.html` | Sunum sayfası (klasör yapısıyla çalışır) |

## Kurgu ve etkileşim

Yerleşim üç sütun: **solda** tr.pandora.net’in kendi model çekimi (Ken Burns ile yavaşça açılır) ve üzerinde logo, kampanya çipi, başlık, CTA; **ortada** Pandora pembesi zemin + ışık halesi üzerinde büyük bileklik packshot’ı ve charm yuvaları; **sağda** buzlu cam panelde metal seçimi, charm tepsisi ve canlı toplam.

1. **Açılış (0–1,4 sn)** – Fotoğraf yumuşak zoom’la belirir, Pandora logosu ve “3 AL 2 ÖDE · Pandora Club’a özel” çipi gelir; “PANDORA MOMENTS / Kendi hikâyeni / tasarla.” satır satır yükselir, beyaz CTA. Ortada “Bilekliğini seç, charm’larını ekle, anını taşı.”
2. **Bileklik (0,75 sn)** – Pandora Moments yılan zincir bileklik packshot’ı hafif dönerek sahneye oturur, altında ürün adı/fiyatı; sağ panel buzlu camla süzülür; metal üzerinde ara ara ışıltılar.
3. **Gösteri (2,6 sn →)** – Kullanıcı dokunmazsa tepsiden üç charm sırayla bilekliğe uçar; yerine oturunca ışıltı + halka, toplam sayarak artar.
4. **Dinlenme (~7,5 sn)** – CTA “Bu tasarımı satın al” olur ve nabız atar; takılı charm’lar hafifçe salınır, boş yuvalar kesikli halkayla davet eder. 30 sn’de Ken Burns ve nabız durur (IAB / Google 30 sn kuralı), etkileşim sürer.

- **Metal:** Gümüş / Rose / Altın – bileklik fotoğrafı çapraz geçişle değişir, ürün adı ve fiyatı güncellenir (klavyede ← →). Charm yuvaları bileklik başına tanımlıdır (klipsin üstüne gelmez).
- **Charm ekle:** tepsideki gerçek charm fotoğrafına tıkla → yuvaya uçar; en fazla 5. Ekli charm’a (tepside ✓, bileklikte ×) tıklayınca çıkar; “Temizle” hepsini kaldırır. Üzerine gelince ürün satırında ad + fiyat.
- **Toplam:** bileklik + charm liste fiyatları TL olarak canlı toplanır.
- **Çıkış:** CTA, başlık ve boş alanlar `clickTag` (varsayılan: Pandora Moments koleksiyonu, UTM’li); bileklik fotoğrafı seçili bilekliğin ürün sayfasına derin bağlantı (clickTag reklam ağı tarafından tanımlanmışsa o kullanılır). Panel kontrolleri çıkış tetiklemez.
- **Ses:** varsayılan kapalı; kullanıcı hoparlör simgesine basarsa takma/çıkarma için kısa WebAudio tıkları.
- **Devralma:** kurgu/gösteri yalnızca gerçek fare hareketi, dokunma veya tıklama ile durur (imlecin reklam üzerinde durması bozmaz).
- Klavye, dokunmatik, `prefers-reduced-motion` (kurgu/gösteri atlanır, doğrudan dinlenme), `aria-live` ürün satırı.

## Teknik

- Tek HTML (~450 KB); CSS/JS satır içi, ES5, harici kütüphane yok. Model fotoğrafı ve ürün packshot’ları (fonu temizlenmiş, 2× WebP), logo SVG, Inter fontu (Latin + Türkçe alt kümesi, ~50 KB) base64 gömülü → harici istek yok. `--no-embed-fonts` ile Google Fonts bağlantısı (~400 KB). Rich media / masthead yerleşimi içindir; 150 KB sınırlı standart banner yuvaları için görselleri küçültmek gerekir (`tools/optimize-assets.js --bracelet=480 --charm=120 --quality=0.7`).
- `<meta name="ad.size">`, `var clickTag`, `Enabler.exit` / `Enabler.counter` (Studio/DV360; `Enabler` varsa `INIT` beklenir), `window.adTrack(olay)` kancası: `impression_start, interact, metal_<key>, charm_add_<key>, charm_remove, reset, sound_on, demo_complete, cta_click, exit`.
- Sekme gizlenince zamanlayıcılar durur; 30 sn sonra `is-still`.

## Veri: tr.pandora.net’ten alınanlar

Bulut oturumunun ağ politikası tr.pandora.net’e erişemediği için görseller, adlar ve fiyatlar **GitHub Actions** üzerinde çalışan toplayıcıyla (`tools/fetch-assets.js`, Playwright/Chromium) alınır: ürün sayfalarından JSON-LD / galeri görselleri (packshot + model çekimi), listeleme kartları, ana sayfadaki kampanya görselleri, üst menüdeki logo SVG’si ve site fontu/renkleri. tr.pandora.net zaman zaman bekleme odasıyla (403 “Bir dakika lütfen…”) yanıt verir; o durumda betik Pandora’nın yeni platformu **www.pandora.net/tr-tr** (aynı ürünler, TL fiyatlar) ve son çare Wayback Machine’e (yalnız ad/fiyat) düşer. Kısmi çalıştırma (`only` girdisi) mevcut manifest’e birleştirilir.

Marka varlıkları:

- **Logo:** www.pandora.net/tr-tr üst menüsündeki satır içi SVG (`assets/logo/inline-home-0-*.svg`), fotoğraf üzerinde beyaz.
- **Fotoğraf:** ana sayfadaki Pandora Moments 2026 Q3 kampanya görseli (`assets/site/home-11-…moments….webp`), 3:4 kaynaktan 330×250 sütuna kırpıldı (`assets/pick.json → hero.crop`).
- **Yazı tipi:** site Gotham SSm kullanıyor (lisanslı); en yakın açık font **Montserrat** (Google Fonts) gömüldü; başlıklar sitedeki gibi büyük harf.
- **Renkler:** Pandora pembesi zemin (#f7e9ec → #efd6dd), mürekkep #1f1e1c, vurgu #c8104e.

Ürünler (`src/data.js`):

| Anahtar | Ürün | Kod | Fiyat (TL) |
|---|---|---|---|
| silver | Pandora Moments Yılan Zinciri Ayarlanabilir Bileklik | 599652C01 | 4.479 |
| rose | Moments 14 Ayar Pembe Altın Kaplama Bileklik | 580728 | 5.449 |
| gold | Moments 14 Ayar Altın Kaplama Düz Klipsli Bileklik | 568748C00 | 5.609 |
| hearts | İç İçe Sonsuz Kalpler Charm | 790800C00 | 999 |
| murano | Mat Pembe Murano Cam Charm | 789421C00 | 2.699 |
| galaxy | Galaksi Mavisi ve Yıldız Murano Charm | 790015C00 | 2.779 |
| butterfly | Mavi Kelebek Işıltılı Charm | 790761C01 | 3.579 |
| clip | Mavi Pavé Klips Charm | 791817NSBMX | 2.699 |
| bigbutterfly | Büyük Kelebek Charm | 793747C01 | 4.349 |

Fiyatlar ve packshot’lar 22 Eylül 2026’da tr.pandora.net ürün sayfalarından (tarayıcıyla) alındı; `assets/manifest.json` kaynağı ve adresi tutar. Tepside ilk 6 charm gösterilir; `star` (792368C01) sitede görselsiz kaldığı için `assets/pick.json` ile atlandı.

Kampanya: “3 Al 2 Öde” (Pandora Club üyelerine özel, seçili mücevherlerde 3 ürün seç 1’i hediye) – tr.pandora.net ana sayfa, Eylül 2026. Fiyatlar liste fiyatıdır; yayın öncesi güncel fiyat ve kampanya koşullarının markayla teyidi önerilir.

## Komutlar

```bash
# 1) Gerçek görseller: GitHub → Actions → "Siteden görselleri çek ve derle" → task: pandora → Run workflow
#    (assets/manifest.json, assets/src/, assets/logo/, assets/site/, assets/sheets/ dala push'lanır)
# 2) Seçim: assets/pick.json (hangi ürünün hangi görseli, hero fotoğrafı ve odak noktası, logo)
NODE_PATH=$(npm root -g) node tools/optimize-assets.js   # fon temizleme, kırpma, WebP → assets/opt/ + opt.json
bash tools/subset-fonts.sh                               # (bir kez) Inter alt kümesi → assets/fonts/inter-subset.css
node build.js                                            # dist/970x250/index.html, zip, release/Pandora2027.html
NODE_PATH=$(npm root -g) node tools/capture.js           # preview/screens/*.jpg  (--video: preview/video/)
NODE_PATH=$(npm root -g) node tools/smoke.js             # etkileşim duman testi (--quick: 30 sn testini atlar)
node tools/package.js                                    # release/sunum.html + teslim zip'i
```

Görsel yoksa `node build.js` vektör yer tutucularla (halka + renkli diskler) derler; `--vector` bunu zorlar.

## Özelleştirme

Metinler, kampanya, ürünler (kod, ad, fiyat, adres), metal renkleri, charm yuva konumları (`stage.slots`), gösteri sırası (`demoOrder`) ve süreler `src/data.js` içindedir. Renkler `src/styles.css` → `:root`.
